/*
 * cserial.h
 *
 *  Created on: Sep 26, 2016
 *      Author: su
 */

#ifndef CSERIAL_H_
#define CSERIAL_H_

#include "common_msgs/msgdata.h"

#define         SERIAL_DATA_LEN                  1024                 //串口数据最大大小
#define         SERIAL_DATA_CONST_SIZE           13                   //帧数据固定大小（1帧头+2帧长度+4指令码+4预留位+1校验+1帧尾）
#define         SERIAL_DATA_CONST_SIZE2          3                    //帧数据固定大小（1帧头+1校验+1帧尾）

class CSerial {
public:
	virtual ~CSerial(){};
	virtual int serial_read_data() = 0;
	virtual int parse_data(common_msgs::msgdata* msg_data) = 0;
	virtual int serial_send_data(const common_msgs::msgdata& msg_data) = 0;
};

#endif /* CSERIAL_H_ */

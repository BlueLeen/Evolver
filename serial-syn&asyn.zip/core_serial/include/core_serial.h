#ifndef __CORE_SERIAL_H__
#define __CORE_SERIAL_H__

//#include "common_func/evointerface.h"
#include "common_func/commu.h"
#include "cserial.h"

class CoreSerial : public CSerial
{
public:
	CoreSerial();
	virtual ~CoreSerial();
	int serial_read_data();
	int parse_data(common_msgs::msgdata* msg_data);
	int serial_send_data(const common_msgs::msgdata& msg_data);
	bool isReady(){return m_bState;}
private:
	Commu* m_pCommu;
	bool m_bState;
	uint8 m_ucRecvData[SERIAL_DATA_LEN];
};

#endif

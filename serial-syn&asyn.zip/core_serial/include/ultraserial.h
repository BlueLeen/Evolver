/*
 * ultraserial.h
 *
 *  Created on: Sep 26, 2016
 *      Author: su
 */

#ifndef ULTRASERIAL_H_
#define ULTRASERIAL_H_
#include "common_func/commu.h"
#include "cserial.h"

class UltraSerial: public CSerial {
public:
	UltraSerial();
	virtual ~UltraSerial();
	int serial_read_data();
	int parse_data(common_msgs::msgdata* msg_data);
	int serial_send_data(const common_msgs::msgdata& msg_data);
	bool isReady(){return m_bState;}
private:
	Commu* m_pCommu;
	bool m_bState;
	sint32 m_nSize;
	uint8 m_ucRecvData[SERIAL_DATA_LEN];
};

#endif /* ULTRASERIAL_H_ */

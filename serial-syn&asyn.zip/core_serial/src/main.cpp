#include <ros/ros.h>
#include <boost/thread.hpp>
#include "core_serial.h"
#include "ultraserial.h"
#include "common_msgs/msgdata.h"
#include "common_msgs/single_status.h"
#include "common_msgs/power_detection_status.h"
#include "common_msgs/common.h"

#define         PARSEMODULE(x)                          (((x) >> 16) & 0xffff)               // 模块解析

typedef std::map<int, ros::Publisher> M_Publisher;

static ros::NodeHandle*     g_nh;
static boost::thread*       g_thread_pad = NULL;
static boost::thread*       g_thread_ultra = NULL;
static M_Publisher          g_m_pub;
static ros::V_Subscriber    g_v_sub;

static CoreSerial* g_pCore = NULL;
static UltraSerial* g_pUltra = NULL;

void serial_cmd_to_pad(const common_msgs::msgdata& msg)
{
    if(0 != g_pCore->serial_send_data(msg))
        evo_msg("serial cmd to pad err");
}

void serial_cmd_to_ultra(const common_msgs::msgdata& msg)
{
	if(0 != g_pUltra->serial_send_data(msg))
		evo_msg("serial cmd to ultrasonic err");
}

void thread_func_pad()
{
    common_msgs::msgdata msg;
    M_Publisher::iterator iter;
    evo_msg("start to read&parse pad's serial data");
    while(1)
    {
        if(0 == g_pCore->serial_read_data())
        {
        	evo_msg("read pad's serial data");
            if(0 == g_pCore->parse_data(&msg))
            {
                iter = g_m_pub.find(PARSEMODULE(msg.cmd));
                if(iter != g_m_pub.end())
                {
                    iter->second.publish(msg);
                }
            }
        }

        boost::this_thread::sleep(boost::posix_time::millisec(20));
    }
}

void thread_func_ultra()
{
	common_msgs::msgdata msg;
	M_Publisher::iterator iter;
	evo_msg("start to read&parse ultra's serial data");
    while(1)
    {
        if(0 == g_pUltra->serial_read_data())
        {
        	evo_msg("read ultra's serial data");
            if(0 == g_pUltra->parse_data(&msg))
            {
                iter = g_m_pub.find(PARSEMODULE(msg.cmd));
                if(iter != g_m_pub.end())
                {
                    iter->second.publish(msg);
                }
            }
        }

        boost::this_thread::sleep(boost::posix_time::millisec(20));
    }
}

int set_publisher_init()
{
    g_m_pub.clear();
    g_m_pub.insert(std::make_pair(NODE_IO_DETECTION, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_io_detection", 100)));
    g_m_pub.insert(std::make_pair(NODE_POWER_DETECTION, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_power_detection", 100)));
    g_m_pub.insert(std::make_pair(NODE_MOTION, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_motion", 100)));
    g_m_pub.insert(std::make_pair(NODE_ULTRASONIC, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_ultrasonic", 100)));
    g_m_pub.insert(std::make_pair(NODE_INFRARED, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_infrared", 100)));
    g_m_pub.insert(std::make_pair(NODE_UPGRADE, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_upgrade", 100)));
    g_m_pub.insert(std::make_pair(NODE_NAVIGATION, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_navi_move", 100)));
    g_m_pub.insert(std::make_pair(NODE_MAP_MANAGER, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_map_maintain", 100)));
    g_m_pub.insert(std::make_pair(NODE_LOCAL_INFO, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_local_info", 100)));
    g_m_pub.insert(std::make_pair(NODE_LOCALIZATION, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_localization", 100)));
    g_m_pub.insert(std::make_pair(NODE_CAMERA, g_nh->advertise<common_msgs::msgdata>("serial_cmd_to_camera", 100)));
    g_m_pub.insert(std::make_pair(NODE_ULTRASONIC_DOWN, g_nh->advertise<common_msgs::msgdata>("ultrasonic_read_data", 100)));

    return 0;
}

int set_subscriber_init()
{
    g_v_sub.clear();
    g_v_sub.push_back(g_nh->subscribe("serial_cmd_to_pad", 1000, serial_cmd_to_pad));
    g_v_sub.push_back(g_nh->subscribe("serial_cmd_to_ultra", 1000, serial_cmd_to_ultra));

    return 0;
}

int serial_open()
{
    set_publisher_init();
    set_subscriber_init();
    g_pCore = new CoreSerial();
    g_pUltra = new UltraSerial();
    if(!g_pCore->isReady())
    	return -1;
    if(!g_pUltra->isReady())
    	return -1;

    g_thread_pad = new boost::thread(boost::bind(thread_func_pad));
    g_thread_ultra = new boost::thread(boost::bind(thread_func_ultra));
    return 0;
}

int serial_close()
{
    if(NULL != g_thread_pad)
    {
    	g_thread_pad->interrupt();
    	g_thread_pad->join();
        delete g_thread_pad;
        g_thread_pad = NULL;
    }
    if(NULL != g_thread_ultra)
    {
    	g_thread_ultra->interrupt();
    	g_thread_ultra->join();
    	delete g_thread_ultra;
    	g_thread_ultra = NULL;
    }

    return 0;
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "core_serial", ros::init_options::NoRosout);
    g_nh = new ros::NodeHandle();
    if(0 != serial_open())
    {
        evo_msg("serial to pad open err");
        return -1;
    }
    while(ros::ok())
    {
        ros::spin();
    }
    serial_close();
    if(NULL != g_nh)
    {
        delete g_nh;
        g_nh = NULL;
    }

    return 0;
}


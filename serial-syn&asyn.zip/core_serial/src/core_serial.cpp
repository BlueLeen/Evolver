#include "core_serial.h"
#include <string.h>
#include <stdio.h>
#include "common_msgs/common.h"
#include "common_func/comfactory.h"
#include "common_func/serialfactory.h"
#include "common_func/comserial.h"


CoreSerial::CoreSerial(): m_pCommu(NULL), m_bState(false)
{
	CommuFactory* cf = new SerialFactory((int)E_SERIAL_PAD);
	m_pCommu =  cf->createCommu();
	if(m_pCommu->open())
	{
		m_bState = true;
		evo_msg("serial open success.");
	}
	memset(m_ucRecvData, 0, sizeof(m_ucRecvData));
}

CoreSerial::~CoreSerial()
{
	if(m_pCommu != NULL)
	{
		m_pCommu->close();
		delete m_pCommu;
	}
	m_pCommu = NULL;
}

int CoreSerial::serial_read_data()
{
	sint32 size = 0;
	if(m_pCommu->recvData(m_ucRecvData, size))
		return 0;

    return -1;
}

int CoreSerial::parse_data(common_msgs::msgdata* msg_data)
{
    if(NULL == msg_data)
    {
        return -1;
    }
    uint32 i = 0;
    for(i = 2; i < 6; i++)
    {
        msg_data->cmd = (msg_data->cmd << 8) | m_ucRecvData[i];
    }

    uint16 length = (m_ucRecvData[0] << 8) | m_ucRecvData[1];
    if(length < SERIAL_DATA_CONST_SIZE || length > SERIAL_DATA_LEN)
    {
        return -1;
    }

    msg_data->inlen = length - SERIAL_DATA_CONST_SIZE;

    if(msg_data->inlen > 0)
    {
        msg_data->input.resize(msg_data->inlen);
        memcpy((void*)&msg_data->input[0], &m_ucRecvData[6], msg_data->inlen);
    }
    else if(msg_data->inlen < 0)
    {
        return -1;
    }

    printf("serial recv cmd:0x%x inlen:%d input", msg_data->cmd, msg_data->inlen);
    if(msg_data->inlen < 128)
    {
        for(i = 0; i < msg_data->inlen; i++)
        {
            printf("  0x%02x", msg_data->input[i]);
        }
    }
    printf("\n");

    memcpy((void*)&msg_data->reserved[0], &m_ucRecvData[6 + msg_data->inlen], 4);
    return 0;
}

int CoreSerial::serial_send_data(const common_msgs::msgdata& msg_data)
{
    uint8 tmp[SERIAL_DATA_LEN] = {0};
    int length_before = 0;
    length_before = SERIAL_DATA_CONST_SIZE + msg_data.inlen;
    tmp[0] = (((length_before) >> 8) & 0xff);
    tmp[1] = ((length_before) & 0xff);
    tmp[2] = ((msg_data.cmd & 0xff000000) >> 24);
    tmp[3] = ((msg_data.cmd & 0xff0000) >> 16);
    tmp[4] = ((msg_data.cmd & 0xff00) >> 8);
    tmp[5] = (msg_data.cmd & 0xff);
    memcpy(&tmp[6], (void*)&msg_data.input[0], msg_data.inlen);
    memcpy((&tmp[6 + msg_data.inlen]), (void*)&msg_data.reserved[0], 4);

//    evo_msg("serial send cmd:0x%x inlen:%d input\n", msg_data.cmd, msg_data.inlen);
    printf("serial send cmd:0x%x inlen:%d input", msg_data.cmd, msg_data.inlen);
    int i = 0;
    if(msg_data.inlen < 128)
    {
        for(i = 0; i < (int)msg_data.inlen; i++)
        {
            printf("  0x%02x", msg_data.input[i]);
        }
    }
    printf("\n");
    m_pCommu->sendData(tmp, 6 + msg_data.inlen + 4);
    return 0;
}

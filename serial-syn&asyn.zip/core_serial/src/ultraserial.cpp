/*
 * ultraserial.cpp
 *
 *  Created on: Sep 26, 2016
 *      Author: su
 */

#include "ultraserial.h"
#include "common_msgs/common.h"
#include "common_func/comfactory.h"
#include "common_func/serialfactory.h"
#include "common_func/comserial.h"


UltraSerial::UltraSerial():m_pCommu(NULL), m_bState(false), m_nSize(0) {
	// TODO Auto-generated constructor stub
	CommuFactory* cf = new SerialFactory((int)E_ULTRASONIC);
	m_pCommu =  cf->createCommu();
	if(m_pCommu->open())
	{
		evo_msg("serial open success.");
		m_bState = true;
	}
	memset(m_ucRecvData, 0, sizeof(m_ucRecvData));
}

UltraSerial::~UltraSerial() {
	// TODO Auto-generated destructor stub
	if(m_pCommu != NULL)
	{
		m_pCommu->close();
		delete m_pCommu;
	}
	m_pCommu = NULL;
}

int UltraSerial::serial_read_data()
{
	if(m_pCommu->recvData(m_ucRecvData, m_nSize))
		return 0;

	return -1;
}

int UltraSerial::parse_data(common_msgs::msgdata* msg_data)
{
    if(NULL == msg_data)
    {
        return -1;
    }
    msg_data->cmd = (NODE_ULTRASONIC_DOWN << 16) | 0;
    msg_data->inlen = m_nSize;
    if(msg_data->inlen > 0)
    {
        msg_data->input.resize(msg_data->inlen);
        memcpy((void*)&msg_data->input[0], &m_ucRecvData[0], msg_data->inlen);
    }
    else if(msg_data->inlen < 0)
    {
        return -1;
    }
    printf("serial recv cmd:0x%x inlen:%d input", msg_data->cmd, msg_data->inlen);
    if(msg_data->inlen < 128)
    {
        for(unsigned int i = 0; i < msg_data->inlen; i++)
        {
            printf("  0x%02x", msg_data->input[i]);
        }
    }
    printf("\n");
    memset(&msg_data->reserved[0], 0, 4);
	return 0;
}

int UltraSerial::serial_send_data(const common_msgs::msgdata& msg_data)
{
    uint8 tmp[SERIAL_DATA_LEN] = {0};
    memcpy(&tmp[0], (void*)&msg_data.input[0], msg_data.inlen);
    printf("serial send cmd:0x%x inlen:%d input", msg_data.cmd, msg_data.inlen);
    int i = 0;
    if(msg_data.inlen < 128)
    {
        for(i = 0; i < (int)msg_data.inlen; i++)
        {
            printf("  0x%02x", msg_data.input[i]);
        }
    }
    printf("\n");
    m_pCommu->sendData(tmp, msg_data.inlen);
	return 0;
}

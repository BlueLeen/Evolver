# intelligence-linux-ors-common-func

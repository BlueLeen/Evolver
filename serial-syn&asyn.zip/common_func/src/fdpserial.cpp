/*
 * fdpserial.cpp
 *
 *  Created on: Sep 20, 2016
 *      Author: su
 */

#include "fdpserial.h"
#include <stddef.h>
#include <sys/time.h>

#define         SERIAL_DATA_LEN                  1024                 //串口数据最大大小

uint8 SerialTool::l_u08_init_flag = 0;
Serial_Handle SerialTool::g_platform_serial[ALL_SERIALS_NUM+1];
const int SerialTool::rate_array[] = {2400, 4800, 9600,115200};

typedef struct
{
	uint8 u08_serial_opened_flag; /*0-closed;1-opened*/
	uint8 u08_reserved1;
	uint8 u08_reserved2;
	uint8 u08_reserved3;
}Fdp_Serial_Flag,PFdp_Serial_Flag;

typedef struct
{
	Fdp_Serial_Flag serial_flag;
	uint32 serialhandle_for_motionCard;
}Fdp_Serial_Hdl,PFdp_Serial_Hdl;

FdpSerial::FdpSerial(bool bAsyn):m_pSerHandle(NULL), m_pThreadRecv(NULL), m_pMem(NULL) {
	// TODO Auto-generated constructor stub
	m_pMem = new MemCache(bAsyn);
}

FdpSerial::~FdpSerial() {
	// TODO Auto-generated destructor stub
	if(m_pMem != NULL)
		delete m_pMem;
	m_pMem = NULL;
}

/*******************************************************************************
* 函数名称: fdp_serial_open
* 功能描述: 初始化串口
* 参数:
*      [输入参数]：
*                pu32_serial_hdl:用于带回串口句柄；
				 serial_type:指示当前串口类别
*      [输出参数]:
*                无
* 返回值:
*        返回错误号---失败
*        0         ---成功
* 其他说明:
*
*******************************************************************************/
int FdpSerial::fdpSerialOpen(SERIAL_TYPE serial_type)
{
	Fdp_Serial_Hdl* pfdp_serial_hdl = NULL;
	SerialTool::platformSerialInit();
	/*安全监测*/
	if(!SerialTool::isSerialTypeValid(serial_type))
	{
        printf("fdp_serial_open:param is invalid!\n");
        return -1;
	}

	if(0 != SerialTool::g_platform_serial[serial_type].serial_note.u08_opened_num)
	{
		m_pSerHandle = &SerialTool::g_platform_serial[serial_type];
		SerialTool::g_platform_serial[serial_type].serial_note.u08_opened_num++;
        return 0;
	}

	pfdp_serial_hdl = (Fdp_Serial_Hdl*)malloc(sizeof(Fdp_Serial_Hdl));
	if(NULL == pfdp_serial_hdl)
	{
        return -1;
	}
	bzero((char*)pfdp_serial_hdl,sizeof(Fdp_Serial_Hdl));

    if(SerialTool::uartOpen((int*)&pfdp_serial_hdl->serialhandle_for_motionCard,serial_type) <0)
    {
        printf("fdp_serial_open:****************open failed\n");
		free(pfdp_serial_hdl);
		pfdp_serial_hdl = NULL;
        return -1;
    }
	/*默认设置115200,8,N,1*/
    if(SerialTool::uartSet(pfdp_serial_hdl->serialhandle_for_motionCard, E_BAUERATE_115200, E_DATA_BITS_8, E_CHECK_NONE, E_ONE_BIT)<0)
    {
        printf("fdp_serial_open:****************set failed\n");
        SerialTool::uartClose(pfdp_serial_hdl->serialhandle_for_motionCard);
		pfdp_serial_hdl->serialhandle_for_motionCard = -1;
		free(pfdp_serial_hdl);
		pfdp_serial_hdl = NULL;
        return -1;
    }

    printf("fdp_serial_open:****************end\n");

    SerialTool::g_platform_serial[serial_type].serial_note.serial_protocol_num= SERIAL_PROTO_FDP;
    SerialTool::g_platform_serial[serial_type].serial_note.u08_opened_num++;
    SerialTool::g_platform_serial[serial_type].pu32_curr_sio_hdl = (uint32*)pfdp_serial_hdl;
    m_pSerHandle = &SerialTool::g_platform_serial[serial_type];

    return 0;
}

/*******************************************************************************

* 函数名称: fdp_serial_close
* 功能描述: 关闭串口
* 参数:
*      [输入参数]：
*                u32_serial_hdl:串口句柄
*      [输出参数]:
*                无
* 返回值:
*        返回错误号---失败
*        0         ---成功
* 其他说明:
*
*******************************************************************************/
int FdpSerial::fdpSerialClose()
{
	Fdp_Serial_Hdl* pfdp_serial_hdl = NULL;

	if(NULL == m_pSerHandle)
	{
        printf("fdp_serial_close:serial not open!\n");
        return -1;
    }

	pfdp_serial_hdl = (Fdp_Serial_Hdl*)m_pSerHandle->pu32_curr_sio_hdl;

	if( SERIAL_PROTO_FDP!= m_pSerHandle->serial_note.serial_protocol_num)
	{
        printf("fdp_serial_close:sio pro wrong!\n");
        return -1;
    }

	if(0 == m_pSerHandle->serial_note.u08_opened_num)
	{
        printf("fdp_serial_close:sio is closed!\n");
        return -1;
    }
	else if(m_pSerHandle->serial_note.u08_opened_num>1)
	{
		m_pSerHandle->serial_note.u08_opened_num--;
        return 0;
	}
	else /*==1*/
	{
		m_pSerHandle->serial_note.u08_opened_num = 0;
		m_pSerHandle->serial_note.serial_protocol_num = (Serial_Protocol_Type)0;

		SerialTool::uartClose(pfdp_serial_hdl->serialhandle_for_motionCard);
		pfdp_serial_hdl->serialhandle_for_motionCard = -1;

		free(m_pSerHandle->pu32_curr_sio_hdl);
		m_pSerHandle->pu32_curr_sio_hdl = NULL;
        return 0;
	}
    if(NULL != m_pThreadRecv)
    {
    	m_pThreadRecv->interrupt();
    	m_pThreadRecv->join();
        delete m_pThreadRecv;
        m_pThreadRecv = NULL;
        printf("fdp_serial_close:receive thread terminate!\n");
    }
    return 0;
}

/*******************************************************************************

* 函数名称: fdp_serial_set
* 功能描述: 设置串口
* 参数:
*      [输入参数]：
*                u32_serial_hdl：串口句柄
				 p_serial_attr：串口属性
*      [输出参数]:
*                无
* 返回值:
*        返回错误号---失败
*        0         ---成功
* 其他说明:
*
*******************************************************************************/
int FdpSerial::fdpSerialSet(Serial_Attr* p_serial_attr)
{
	Fdp_Serial_Hdl* pfdp_serial_hdl = NULL;

	if((NULL==m_pSerHandle)
		||(!SerialTool::isSerialBaudrateValid(p_serial_attr->baudrate))
		||(!SerialTool::isSerialDatabitsValid(p_serial_attr->data_bits))
		||(!SerialTool::isSerialCheckTypeValid(p_serial_attr->check_type))
		||(!SerialTool::isSerialStopbitsValid(p_serial_attr->stop_bits)))
	{
        printf("fdp_serial_set:param is invalid!\n");
        return -1;
    }

	pfdp_serial_hdl = (Fdp_Serial_Hdl*)m_pSerHandle->pu32_curr_sio_hdl;

	if( SERIAL_PROTO_FDP!= m_pSerHandle->serial_note.serial_protocol_num)
	{
        printf("fdp_serial_set:sio pro wrong!\n");
        return -1;
    }

	if(0 == m_pSerHandle->serial_note.u08_opened_num)
	{
        printf("fdp_serial_set:sio is closed!\n");
        return -1;
    }

	if(SerialTool::uartSet(pfdp_serial_hdl->serialhandle_for_motionCard, p_serial_attr->baudrate,
				p_serial_attr->data_bits, p_serial_attr->check_type, p_serial_attr->stop_bits)<0)
    {
        printf("fdp_serial_set:set failed,close the serial!\n");

        m_pSerHandle->serial_note.u08_opened_num = 0;

		fdpSerialClose();
        return -1;
    }

    return 0;
}

/*******************************************************************************
* 函数名称: formatPacket
* 功能描述: 封装串口格式
* 参数:
*      [输入参数]：
*                srcbuf：存储串口数据的缓冲指针(无转义符的数据)
				 destbuf:用于存储转义之后的数据；
				 srclen：写入数据的长度
*      [输出参数]:
*                转移后的数据
* 返回值:
*        返回错误号        ---失败
*        转义后的数据长度  ---成功
* 其他说明:
*
*******************************************************************************/
sint32 FdpSerial::fdpFormatPacket( uint8*srcbuf, /*源buf*/
					     		 uint8 *destbuf, /*slip打包后的buf*/
						 		 uint32 srclen /*slip 打包前的长度*/
					  			)
{
	uint32 i, j;
	j = 0;
	destbuf[0] = START;
	i = 1;
	while (srclen--) {
		switch (srcbuf[j]) {
		case START:
			destbuf[i++] = ESC;
			destbuf[i++] = ESC_START;
			break;
		case END:
			destbuf[i++] = ESC;
			destbuf[i++] = ESC_END;
			break;

		case ESC:
			destbuf[i++] = ESC;
			destbuf[i++] = ESC_ESC;
			break;

		default:

			destbuf[i++] = srcbuf[j];
		}
		j++;
	}

	destbuf[i++] = END;
	return i;
}

/*******************************************************************************
* 函数名称: fdp_serial_read
* 作    者: jjz,dk
* 功能描述: 读取串口整包数据,且一次读取串口多个字节
* 参数:
*      [输入参数]：
*                u32_serial_hdl：串口句柄
				 pu8_read_buf：存储串口数据缓冲区；
				 u32_max_len：缓冲长度(读取最大长度)
*      [输出参数]:
*                串口整包数据,去掉了枕头帧尾和转义字符
* 返回值:
*        返回错误号        ---失败
*        读取到的数据长度  ---成功
* 其他说明: 较前版本进行了优化操作，串口每次read操作最大读入1024字节
*     		检测到完整一帧则发送，剩余数据进行存储
*			故每次调用要首先检查缓存数据
*
*******************************************************************************/

sint32 FdpSerial::fdpSerialRead(uint8* pu8_read_buf,uint32 u32_max_len)
{
	sint32 nLen = 0;
	uint32 nCheck = 0;
	if((NULL==m_pSerHandle)
		||(NULL==pu8_read_buf)
		||(0==u32_max_len))
	{
        printf("fdp_serial_read:param is invalid!\n");
        return -1;
    }

	if( SERIAL_PROTO_FDP!= m_pSerHandle->serial_note.serial_protocol_num)
	{
		printf("fdp_serial_read:sio pro wrong!\n");
        return -1;
    }

	if(0 == m_pSerHandle->serial_note.u08_opened_num)
	{
		printf("fdp_serial_read:sio is closed!\n");
        return -1;
    }
	//evo_msg("fdp_serial_read:before thread_recv!\n");
	if(m_pThreadRecv == NULL)
	{
		printf("fdpSerialRead:: new thread_recv!!!\n");
		m_pThreadRecv = new boost::thread(boost::bind(&FdpSerial::thread_recv, this));
	}
	while(1)
	{
		if((nLen = m_pMem->recvDel(pu8_read_buf)) > 0)
		{
			printf("fdpSerialRead:: get data from recv buffer!!!\n");
			//校验读取的数据
		    if((nCheck=fdpCheckSum(pu8_read_buf,nLen)) != 0)
			{
				//printf("fdp_check_sum check error...!\n");
				char errBuf[2048] = { 0 };
				for(int i=0; i<1024; i++)
					sprintf(errBuf, "%s0x%02x ", errBuf, pu8_read_buf[i]);
				errBuf[125] = '\0';
				printf("fdp_check_sum check error, error packet: is %s \n", errBuf);
		        nLen = -1;
			}
		    else
				return (nLen-1);
			break;
		}
		else if(nLen != 0)
		{
			char errBuf[2048] = { 0 };
			for(int i=0; i<256; i++)
				sprintf(errBuf, "%s0x%02x ", errBuf, pu8_read_buf[i]);
			printf("fdp_serial_read:error packet: is %s \n", errBuf);
		}
	}
	return nLen;
}

void FdpSerial::thread_recv()
{
	uint8  uc_char[1024];//read data
	sint32 nSize = 0;
	Fdp_Serial_Hdl* pfdpSerialHdl = NULL;
	pfdpSerialHdl = (Fdp_Serial_Hdl*)m_pSerHandle->pu32_curr_sio_hdl;
	while(1)
	{
    	//evo_msg("fdp_serial_read:receive packet!\n");
		if((nSize = SerialTool::uartRead(pfdpSerialHdl->serialhandle_for_motionCard, (uint8 *)uc_char,1024 )) <= 0)
		{
			usleep(10000);
			continue;
		}
		//char recvbuf[2048] = { 0 };
		//for(int i=0; i<nSize; i++)
		//	sprintf(recvbuf, "%s%02x ", recvbuf, uc_char[i]);
		//write_sys_log(recvbuf, "recvbuf.txt");
		m_pMem->recvAdd(uc_char, nSize);
	}
}

/*******************************************************************************
* 函数名称: fdp_serial_write
* 功能描述: 写串口数据
* 参数:
*      [输入参数]：
				u32_serial_hdl:串口句柄；
				pu8_write_buf:存储串口数据的缓冲指针(无转义符的数据)；
				u32_buf_len:写入数据的长度；
*      [输出参数]:
*                无
* 返回值:
*        返回错误号        ---失败
*        COMMON_OK  	   ---成功
* 其他说明:
*
*******************************************************************************/
sint32 FdpSerial::fdpSerialWrite(uint8* pu8_write_buf,uint32 u32_buf_len)
{
	uint8 u08_buf_to_serial[SERIAL_DATA_LEN] = { 0 };/*用于存储打包好的数据*/
	uint8 u08_buf_with_check[SERIAL_DATA_LEN] = { 0 };/*用于存储打包好的数据*/
	uint32 u32_send_len = 0;
	uint32 i = 0;
	uint8 u08_checksum = 0;
	Fdp_Serial_Hdl* pfdp_serial_hdl = (Fdp_Serial_Hdl*)m_pSerHandle->pu32_curr_sio_hdl;
	//uint32 u32_serial_index = p_serial_hdl.serial_note.u08_serial_index;

	if( SERIAL_PROTO_FDP!= m_pSerHandle->serial_note.serial_protocol_num)
	{
        printf("fdp_serial_write:sio pro wrong!\n");
        return -1;
    }

	if(0 == m_pSerHandle->serial_note.u08_opened_num)
	{
		printf("fdp_serial_write:sio is closed!\n");
        return -1;
    }

	if(SERIAL_DATA_LEN <= u32_buf_len)
	{
		printf("fdp_serial_write:buflen is invalid!\n");
        return -1;
    }

	memcpy(u08_buf_with_check,pu8_write_buf,u32_buf_len);

	/*TODO:计算校验和调用打包函数封装数据*/
	u08_checksum = 0;
	for(i=0; i<u32_buf_len; i++)
	{
		u08_checksum+=u08_buf_with_check[i];
	}
	u08_buf_with_check[i] = u08_checksum&0xff;

	u32_send_len =  fdpFormatPacket(u08_buf_with_check,u08_buf_to_serial,u32_buf_len+1);

//    char buf[1024] = {0};
//    sprintf(buf, "fdp_serial_write:  ");

//    evo_msg("\nfdp_serial_write:index:%d data:", p_serial_hdl->serial_note.u08_serial_index);
//    for(i=0; i<u32_send_len; i++)
//    {
//        evo_msg("%02x ",u08_buf_to_serial[i]);
////        sprintf(&buf[strlen("fdp_serial_write:  ") + 3 * i], "%02x ", u08_buf_to_serial[i]);
//    }
//    evo_msg("\n");

//    int res = evo_log_write(buf);
//    if(0 != res)
//        evo_msg("write log err: %d\n", res);

    u08_buf_to_serial[u32_send_len] = 66;
    u08_buf_to_serial[u32_send_len+1] = 88;
    if(SerialTool::uartWrite(pfdp_serial_hdl->serialhandle_for_motionCard,u08_buf_to_serial, u32_send_len+2) < 0)
	{
        printf("fdp_serial_write:write failed!\n");
        return -1;
	}

    return 0;
}

int FdpSerial::fdpCheckSum(uint8* ucCheckData,uint32 uiCheckNum)
{
    if(uiCheckNum < 1)
        return -1;

	uint32 j;
	uint32 nCheck = 0;

	for(j = 0; j < (uiCheckNum-1); j++)
	{
		nCheck += ucCheckData[j];
	}
    if((nCheck & 0xff) != ucCheckData[uiCheckNum- 1])
		return -1;
	else
		return 0;
}


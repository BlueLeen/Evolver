#include "evointerface.h"
#include <termios.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/select.h>
#include <pthread.h>
#include <unistd.h>
#include <stdarg.h>
#include <sys/time.h>
#include "platform/outputs_user.h"
#include "platform/inputs_user.h"


typedef struct
{
    SERIAL_BAUDRATE rate;
    int fd;
}SERRIAL_HANDLE;


//设置select函数的timeout
#define TIMEOUT_SEC(buflen, baudrate)    ((buflen)*20/(baudrate) + 2)
#define TIMEOUT_USEC    0


static const int rate_array[] = {2400, 4800, 9600,115200};
#define LOCK(mutex)   pthread_mutex_lock( &mutex )
#define UNLOCK(mutex) pthread_mutex_unlock( &mutex)

static int power_cnt = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

//驱动序号锁

static int power_on_off(int level)
{
    evo_msg("power_off lever:%d \n", level);
    int handle,res;
    res = outputs_open(&handle);
    if (res)
        evo_msg("outputs_open error \n");
    res = outputs_set_level(handle,SERIAL_POWER_ON,level);
    if (res)
        evo_msg("outputs_set_level error \n");

    outputs_close(handle);
    return 0;
}

static int motor_system_power_on_off(int level)
{
    int handle = 0;
    if (0 != outputs_open(&handle))
    {
        evo_msg("outputs_open error \n");
        return -1;
    }

    if(1 == level)
    {
        if(0 != outputs_set_level(handle, MOTOR_SYSTEM_POWER_ON, level))
        {
            evo_msg("motor power on err!\n");
            return -1;
        }
    }
    else
    {
        //TODO:目前不需要给电机系统断电
    }

    outputs_close(handle);
    return 0;
}


static int power_open(void)
{
    LOCK(mutex);
    power_cnt++;
    if (power_cnt >1)
    {
        UNLOCK(mutex);
        return 0;
    }
    int level = 1;
    UNLOCK(mutex);
    power_on_off(level);
    return 0;
}


static int power_close(void)
{
    LOCK(mutex);
    power_cnt--;
    if (power_cnt > 0)
    {
        UNLOCK(mutex);
        return 0;
    }

    int level = 0;
    UNLOCK(mutex);
    power_on_off(level);
    return 0;
}

int serial_power_status(SERIAL_TYPE serial_type, int status)
{
    switch (serial_type)
    {
    case E_MOTOR_BOARD:
    {
        if(0 == status)
        {
            power_close();
        }
        else
        {
            //开机自动解锁
            unlock_motor();

            motor_system_power_on_off(status);
            power_open();
        }
    }
        break;
    case E_ULTRASONIC:
    {
        if(0 == status)
        {
            power_close();
        }
        else
        {
            power_open();
        }
    }
        break;

    default:
        break;
    }

    return 0;
}


sint32 uart_tcflush(int handle)
{
	if(handle == 0)
	{
	    perror("error:uart_tcflush handle invalid");
		return -1;
	}
    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
    tcflush(serial->fd, TCIFLUSH);
    return 0;
}


int uart_open(int *handle,SERIAL_TYPE serial_type)
{
    const char *dev[]={"/dev/ttyO0","/dev/ttyO1","/dev/ttyO2","/dev/ttyO3","/dev/ttyO4","/dev/ttyO5"};

    SERRIAL_HANDLE *serial = (SERRIAL_HANDLE *)malloc(sizeof(SERRIAL_HANDLE));
    if (NULL == serial)
        return -1;
    serial->fd = open(dev[(int)serial_type], O_RDWR | O_NOCTTY | O_NDELAY);

    if (-1 == serial->fd)
    {
        perror("Can't Open Serial Port");
        return(-1);
    }

    if(fcntl(serial->fd, F_SETFL, 0) < 0)
    {
        evo_msg("fcntl failed!\n");
    }

    if(isatty(STDIN_FILENO) == 0)
    {
//        evo_msg("standard input is not a terminal device\n");
    }

    *handle = (int)serial;

    return 0;
}

int uart_set(int handle, SERIAL_BAUDRATE speed, DATA_BITS data_bits, CHECK_TYPE check_type, STOP_BITS stop)
{
	if(handle == 0)
	{
	    perror("error:uart_set handle invalid");
		return -1;
	}

    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
    struct termios newtio,oldtio;
    if(tcgetattr( serial->fd,&oldtio) != 0)
    {
        perror("SetupSerial 1");
        return -1;
    }
    bzero(&newtio, sizeof(newtio));
    newtio.c_cflag |= CLOCAL | CREAD;
    newtio.c_cflag &= ~CSIZE;

    switch(data_bits)
    {
    case E_DATA_BITS_7:
        newtio.c_cflag |= CS7;
        break;
    case E_DATA_BITS_8:
        newtio.c_cflag |= CS8;
        break;
    }

    switch(check_type)
    {
    case E_CHECK_ODD:                     //奇校验
        newtio.c_cflag |= PARENB;
        newtio.c_cflag |= PARODD;
        newtio.c_iflag |= (INPCK | ISTRIP);
        break;
    case E_CHECK_EVEN:                     //偶校验
        newtio.c_iflag |= (INPCK | ISTRIP);
        newtio.c_cflag |= PARENB;
        newtio.c_cflag &= ~PARODD;
        break;
    case E_CHECK_NONE:                     //无校验
        newtio.c_cflag &= ~PARENB;
        break;
    }

    switch(speed)
    {
    case E_BAUERATE_2400:
        cfsetispeed(&newtio, B2400);
        cfsetospeed(&newtio, B2400);
        break;
    case E_BAUERATE_4800:
        cfsetispeed(&newtio, B4800);
        cfsetospeed(&newtio, B4800);
        break;
    case E_BAUERATE_9600:
        cfsetispeed(&newtio, B9600);
        cfsetospeed(&newtio, B9600);
        break;
    case E_BAUERATE_115200:
        cfsetispeed(&newtio, B115200);
        cfsetospeed(&newtio, B115200);
        break;
    default:
        cfsetispeed(&newtio, B9600);
        cfsetospeed(&newtio, B9600);
        break;
    }

    if(stop == E_ONE_BIT)
    {
        newtio.c_cflag &= ~CSTOPB;
    }
    else if (stop == E_TWO_BIT)
    {
        newtio.c_cflag |= CSTOPB;
    }

    newtio.c_cc[VTIME] = 0;
    newtio.c_cc[VMIN] = 0;
    tcflush(serial->fd,TCIFLUSH);
    if((tcsetattr(serial->fd,TCSANOW,&newtio))!=0)
    {
        perror("com set error");
        return -1;
    }
    serial->rate = speed;
    return 0;
}

sint32 uart_read(int handle, uint8 *data, sint32 size)
{
	if(handle == 0)
	{
	    perror("error:uart_read handle invalid");
		return -1;
	}

    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
    int len = 0;
    len = read(serial->fd, data, size);
    if (len < 0)
    {
        return -1;
    }
    else
    {
        return (len);
    }
}

sint32 uart_write(int handle, uint8 *data, sint32 size)
{
	if(handle == 0)
	{
	    perror("error:uart_write handle invalid");
		return -1;
	}

    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
    unsigned char *write_data = data;

    int total_len = 0, retval = 0, len = 0;

    fd_set fsWrite;

    struct timeval tvTimeOut;

    memset(&tvTimeOut, 0x00, sizeof(tvTimeOut));

    //每次循环都要清空集合，否则不能检测描述符变化
    FD_ZERO(&fsWrite);

    //存放的是文件描述符即文件句柄
    FD_SET(serial->fd, &fsWrite);
    tvTimeOut.tv_sec  = TIMEOUT_SEC(size, rate_array[serial->rate]);
    tvTimeOut.tv_usec = TIMEOUT_USEC;

    for (total_len = 0; total_len < size;)
    {
        retval = select(serial->fd + 1, NULL, &fsWrite, NULL, &tvTimeOut);

        if (retval < 0)
        {
            return -1;
        }
        else if (retval && FD_ISSET(serial->fd, &fsWrite))
        {
            //往串口写
            len = write(serial->fd, &write_data[total_len], size - total_len);

            if (len > 0)
            {
                total_len += len;
            }
            else if (len < 0)
            {
                if (total_len == 0)
                {
                    //刷新串口
                    tcflush(serial->fd, TCOFLUSH);
                    return -1;
                }
                return total_len;
            }
        }
        else
        {
            if (total_len == 0)
            {
                tcflush(serial->fd, TCOFLUSH);
                return -1;
            }
            break;
        }
    }
    return total_len;
}

int uart_close(int handle)
{
	if(handle == 0)
	{
	    perror("error:uart_close handle invalid");
		return -1;
	}

    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
    if (handle <= 0)
    {
        return -1;
    }
    //关闭串口
    close(serial->fd);
    free(serial);
    return 0;
}

int unlock_motor()
{
    int handle = 0;
    if(0 != inputs_open(&handle))
    {
        return -1;
    }

    int get_value = -1;
    if(0 != get_inputs_code(handle, MOTOR_POWEROFF_CHECK, &get_value))
    {
        return -1;
    }
//    printf("unlock_motorMOTOR_POWEROFF_CHECK %d \n ",get_value);
    if(1 != get_value)
    {
        inputs_close(handle);
        return 0;
    }

    inputs_close(handle);

    int out_handle = 0;
    if(0 != outputs_open(&out_handle))
    {
        return -1;
    }

    int set_value = 1;
    if(0 != outputs_set_level(out_handle, HEAD_UNLOCK, set_value))
    {
        outputs_close(out_handle);
        return -1;
    }

    usleep(20 * 1000);

    set_value = 0;
    if(0 != outputs_set_level(out_handle, HEAD_UNLOCK, set_value))
    {
        outputs_close(out_handle);
        return -1;
    }

//    evo_msg("unlock success!\n");
    outputs_close(out_handle);
    return 0;
}

//小端大端转换，用于平台间传输数据
#define             CHARACTOR_LENGTH_MAX            128      //字符大小端转换最大长度

int litter_big_convert(uint8* dest_data, const uint8* src_data, int length)
{
    if(NULL == dest_data || NULL == src_data)
    {
        return -1;
    }

    int i = 0;
    for(i = 0; i < length; i++)
    {
        dest_data[length - i - 1] = src_data[i];
    }

    return 0;
}


uint8* litter_big_convert_self(uint8* src_data, int length)
{
    if(NULL == src_data || length > CHARACTOR_LENGTH_MAX)
    {
        return NULL;
    }

    uint8 dest_data[CHARACTOR_LENGTH_MAX] = {0};
    memcpy(dest_data, src_data, length);
    memset(src_data, 0, length);

    int i = 0;
    for(i = 0; i < length; i++)
    {
        src_data[length - i - 1] = dest_data[i];
    }

    return src_data;
}


FILE* evo_log_open(const char* file_name, const char* type)
{
    if(NULL == file_name || NULL == type)
    {
        return 0;
    }

    char buf[32] = {0};
    sprintf(buf, "%s/%s", LOG_PATH, file_name);

    evo_msg("open file:%s\n", buf);
    return fopen(buf, type);
}

int evo_log_close(FILE* fp)
{
    if(NULL == fp)
    {
        return -1;
    }

    fclose(fp);
    fp = NULL;
    return 0;
}

int evo_log_write(FILE* fp, char* str, ...)
{
    if(NULL == str || NULL == fp)
        return -1;

    va_list ap;
    char buf[1024] = {0};

    struct timeval t1;
    gettimeofday(&t1, NULL);

    va_start(ap, str);
    vsprintf(buf, str, ap);
    va_end(ap);

    fprintf(fp, "%ld-%ld\t%s\n", t1.tv_sec, t1.tv_usec, buf);
    fflush(fp);

    return 0;
}


//动态申请二维数组
char** malloc_Array2D(int row, int col)
{
    int size = sizeof(char);
    int point_size = sizeof(char*);

    //先申请内存，其中point_size * row表示存放row个行指针
    char **arr = (char **) malloc(point_size * row + size * row * col);
    if (arr != NULL)
    {
        memset(arr, 0, point_size * row + size * row * col);
        char *head = (char*)((int)arr + point_size * row);
        while (row--)
            arr[row] = (char*)((int)head + row * col * size);
    }

    return (char**)arr;
}

//释放二维数组
void free_Aarray2D(void **arr)
{
    if (arr != NULL)
        free(arr);
}

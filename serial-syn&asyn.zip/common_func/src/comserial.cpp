#include "comserial.h"
#include "fdpserial.h"

#define         SERIAL_DATA_LEN                  1024                 //串口数据最大大小

CommuSeiral::CommuSeiral(uint8 type, bool asyn):Commu(), m_pFdpSer(NULL), m_uType(type)
{
	m_pFdpSer = new FdpSerial(asyn);
}

CommuSeiral::~CommuSeiral()
{
	if(m_pFdpSer != NULL)
		delete m_pFdpSer;
	m_pFdpSer = NULL;
}

bool CommuSeiral::open()
{
    if(0 != m_pFdpSer->fdpSerialOpen((SERIAL_TYPE)m_uType))
        return false;
    return true;
}

void CommuSeiral::close()
{
	m_pFdpSer->fdpSerialClose();
}

int CommuSeiral::sendData(uint8* data, uint32 len)
{
	char strType[100] = { 0 };
	getSerialType(strType, sizeof(strType));
    printf("%s send data ", strType);
    int i = 0;
    for(i = 0; i < (int)len; i++)
    {
        printf(" 0x%x", data[i]);
    }
    printf("\n");
    return m_pFdpSer->fdpSerialWrite(data, len);
}

bool CommuSeiral::recvData(uint8* data, sint32& len)
{
	len = m_pFdpSer->fdpSerialRead(data, SERIAL_DATA_LEN);
	if(len <= 0)
	{
		printf("receive data failed!!!\n");
		return false;
	}
	return true;
}

char* CommuSeiral::getSerialType(char* strType, uint32 len)
{
	memset(strType, 0, len);
	switch((SERIAL_TYPE)m_uType)
	{
		case E_SERIAL_PAD:
			strcpy(strType, "core_serial to pad");
			break;
		case E_ULTRASONIC:
			strcpy(strType, "core_serial to ultra");
			break;
		default:
			strcpy(strType, "unknown");
			break;
	}
	return strType;
}

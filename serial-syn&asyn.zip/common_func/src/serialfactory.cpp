/*
 * SerialFactory.cpp
 *
 *  Created on: Sep 27, 2016
 *      Author: su
 */

#include "serialfactory.h"
#include "comserial.h"

SerialFactory::SerialFactory(int type):CommuFactory(),m_nType(type) {
	// TODO Auto-generated constructor stub

}

SerialFactory::~SerialFactory() {
	// TODO Auto-generated destructor stub
}

Commu* SerialFactory::createCommu()
{
	bool bAsyn = false;
	printf("SerialFactory::createCommu--type:%d, synchronous:%s\n", m_nType, bAsyn==true?"false":"true");
	return new CommuSeiral(m_nType, bAsyn);
}


/*
 * MemCache.cpp
 *
 *  Created on: Sep 21, 2016
 *      Author: su
 */

#include "MemCache.h"
#include <unistd.h>

MemCache::MemCache(bool bAsyn):bRecvAsyn(bAsyn) {
	// TODO Auto-generated constructor stub
	arrbuf = new ArrQue<unsigned char>(1048576, bAsyn);
}

MemCache::~MemCache() {
	// TODO Auto-generated destructor stub
	if(arrbuf != NULL)
		delete arrbuf;
	arrbuf = NULL;
}

void MemCache::recvAdd(unsigned char* buf, unsigned int len)
{
	if(bRecvAsyn)
		recvAddAsyn(buf, len);
	else
		recvAddSyn(buf, len);
}

int MemCache::recvDel(unsigned char* buf)
{
	if(bRecvAsyn)
		return recvDelAsyn(buf);
	else
		return recvDelSyn(buf);
}

void MemCache::recvAddSyn(unsigned char* buf, unsigned int len)
{
	unsigned int iCnt = 0;
	while(iCnt < len )
	{
		//if(!arrbuf->addQueue(buf[iCnt]))
		//	continue;
		arrbuf->addQueue(buf[iCnt]);
		//char addbuf[2048] = { 0 };
		//sprintf(addbuf, "%02x ", buf[iCnt]);
		//write_sys_log(addbuf, "addbuf.txt");
		++iCnt;
		//printf("Success");
	}
}

int MemCache::recvDelSyn(unsigned char* buf)
{
	unsigned int uiStartFlag = 0;
	unsigned int uiEndFlag = 0;
	unsigned int uiPacLen = 0;
	unsigned char ucGetEscFlag = 0;
	unsigned char ucSlipPac = 0;
	while(true)
	{
		unsigned char ucChar = 0;
		arrbuf->delQueue(ucChar);
		switch(ucChar)
		{
			case START:
				uiStartFlag = 1;
				uiEndFlag = 0;
				uiPacLen = 0;
				ucSlipPac = 0;
				continue;
			case END:
				uiEndFlag = 1;
				break;
			case ESC:
				if(uiStartFlag != 1)
					break;
				ucGetEscFlag = 1;
				continue;
			default:
				if(uiStartFlag != 1)
					break;
				if(ucGetEscFlag == 1)
				{
					ucGetEscFlag = 0;
					switch(ucChar)
					{
						case ESC_START:
							ucChar = START;
							break;
						case ESC_END:
							ucChar = END;
							break;
						case ESC_ESC:
							ucChar = ESC;
							break;
						default:
							ucSlipPac = 1;
							break;
					}
				}
				buf[uiPacLen++] = ucChar;
				continue;
		}
		if(uiEndFlag)
			break;
	}
	if(ucSlipPac)
	{
		printf("Packet slip packet after ESC...\n ");
		uiPacLen = -1;
	}
	if(uiStartFlag == 0)
	{
		printf("Packet has no start flag:0xFD,esmitate:loss data.\n");
		uiPacLen = -1;
	}
	if(uiEndFlag == 0)
	{
		printf("Packet has no ended flag:0xF8,esmitate:loss data.\n");
		uiPacLen = -1;
	}
	return uiPacLen;
}

void MemCache::recvAddAsyn(unsigned char* buf, unsigned int len)
{
	unsigned int iCnt = 0;
	while(iCnt < len )
	{
		if(!arrbuf->addQueue(buf[iCnt]))
			continue;
		++iCnt;
		//char addbuf[512] = { 0 };
		//sprintf(addbuf, "%c ", buf[iCnt]);
		//write_sys_log(addbuf, "addbuf.txt")
		//printf("Success");
	}
}

int MemCache::recvDelAsyn(unsigned char* buf)
{
	static unsigned int uiStartFlag = 0;
	unsigned int uiEndFlag = 0;
	static unsigned int uiPacLen = 0;
	static unsigned char uiRecvData[2048];
	static unsigned char ucGetEscFlag = 0;
	unsigned char ucSlipPac = 0;
	while(true)
	{
		unsigned char ucChar;
		if(!arrbuf->delQueue(ucChar))
		{
			return 0;
		}
		//char delbuf[512] = { 0 };
		//sprintf(delbuf, "%c ", ucChar);
		//write_sys_log(delbuf, "delbuf.txt")
		switch(ucChar)
		{
			case START:
				uiStartFlag = 1;
				uiEndFlag = 0;
				uiPacLen = 0;
				ucSlipPac = 0;
				continue;
			case END:
				uiEndFlag = 1;
				break;
			case ESC:
				if(uiStartFlag != 1)
				{
					printf("Packet has no start flag:0xFD,esmitate:loss data.\n");
					break;
				}
				ucGetEscFlag = 1;
				continue;
			default:
				if(uiStartFlag != 1)
				{
					printf("Packet has no start flag:0xFD,esmitate:loss data.\n");
					break;
				}
				if(ucGetEscFlag == 1)
				{
					ucGetEscFlag = 0;
					switch(ucChar)
					{
						case ESC_START:
							ucChar = START;
							break;
						case ESC_END:
							ucChar = END;
							break;
						case ESC_ESC:
							ucChar = ESC;
							break;
						default:
							ucSlipPac = 1;
							break;
					}
				}
				uiRecvData[uiPacLen++] = ucChar;
				continue;
		}
		if(uiEndFlag)
			break;
	}
	if(ucSlipPac)
	{
		printf("Packet slip packet after ESC...\n ");
		uiPacLen = -1;
	}
	if(uiStartFlag == 0)
	{
		printf("Packet has no start flag:0xFD,esmitate:loss data.\n");
		uiPacLen = -1;
	}
	if(uiEndFlag == 0)
	{
		printf("Packet has no ended flag:0xF8,esmitate:loss data.\n");
		uiPacLen = -1;
	}
	if(uiEndFlag)
	{
		memcpy(buf, uiRecvData, uiPacLen);
		uiStartFlag = 0;
		uiEndFlag = 0;
		ucSlipPac = 0;
	}
	return uiPacLen;
}


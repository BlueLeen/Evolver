#ifndef ARRQUE_H_
#define ARRQUE_H_

#include <stdio.h>
#include <stddef.h>
#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp> 

template <typename T>
class ArrQue
{
public:
	ArrQue(int nSize=1048576, bool bAsyn=true);
	~ArrQue();
	bool isQueueEmpty();
	bool isQueueFull();
	void printQueue();
	bool addQueue(const T& item);
	bool delQueue(T& item);
private:
	void addQueueSyn(const T& item);
	void delQueueSyn(T& item);
	bool addQueueASyn(const T& item);
	bool delQueueASyn(T& item);
private:
	bool asyn;
    int maxSize; //é˜Ÿåˆ—çš„å¤§å°
    volatile int rear; //æŒ‡å‘é˜Ÿåˆ—çš„é¦–éƒ¨
    volatile int front; //æŒ‡å‘é˜Ÿåˆ—çš„å°¾éƒ¨
    T* list; //é˜Ÿåˆ—çš„é¦–åœ°å€
    //std::mutex mtx; // »¥³âÁ¿,±£»¤²úÆ·»º³åÇø
    //std::condition_variable repo_not_full; // Ìõ¼þ±äÁ¿, Ö¸Ê¾²úÆ·»º³åÇø²»ÎªÂú.
    //std::condition_variable repo_not_empty; // Ìõ¼þ±äÁ¿, Ö¸Ê¾²úÆ·»º³åÇø²»Îª¿Õ.
    boost::mutex  mtx;
    boost::condition_variable_any  repo_not_full;
	boost::condition_variable_any  repo_not_empty;
};

template<typename T>
ArrQue<T>::ArrQue(int nSize, bool bAsyn):asyn(bAsyn), rear(0), front(0)
{
	if(nSize <= 0)
	{
		  nSize = 1048576;
		  list = new T[nSize];
	}
	else
	{
		  list = new T[nSize];
	 }
	maxSize = nSize;
}

template<typename T>
ArrQue<T>::~ArrQue()
{
	if(!list)
	{
		 delete[] list;
	}
	list = NULL;
	rear=0;
	front=0;
}

template<typename T>
bool ArrQue<T>::isQueueEmpty()
{
	return (rear ==front);
}

template<typename T>
void ArrQue<T>::printQueue()
{
}


template<typename T>
bool ArrQue<T>::isQueueFull()
{
	return((rear+1)%maxSize == front);
}

template<typename T>
bool ArrQue<T>::addQueue(const T& item)
{
	if(asyn)
		return addQueueASyn(item);
	else
		addQueueSyn(item);
	return true;
}

template<typename T>
bool ArrQue<T>::delQueue(T& deletedItem)
{
	if(asyn)
		return delQueueASyn(deletedItem);
	else
		delQueueSyn(deletedItem);
	return true;
}

template<typename Type>
void ArrQue<Type>::addQueueSyn(const Type& item)
{
	//std::unique_lock<std::mutex> lock(mtx);
	mtx.lock();
	while(isQueueFull())
	{
		repo_not_full.wait(mtx);
	}
	list[rear] =item;
	//char addque[2048] = { 0 };
	//sprintf(addque, "%02x ", list[rear]);
	//write_sys_log(addque, "addque.txt");				
	rear =(rear+1)%maxSize;
	repo_not_empty.notify_all();
	//lock.unlock();
	mtx.unlock();
}

template<typename T>
void ArrQue<T>::delQueueSyn(T& deletedItem)
{
	//std::unique_lock<std::mutex> lock(mtx);
	mtx.lock();
	while(isQueueEmpty())
	{
		repo_not_empty.wait(mtx);
	}
	deletedItem =list[front];
	//char delque[2048] = { 0 };
	//sprintf(delque, "%02x ", list[front]);
	//write_sys_log(delque, "delque.txt");			
	front =(front+1)%maxSize;
	repo_not_full.notify_all();
	//lock.unlock();
	mtx.unlock();
}

template<typename T>
bool ArrQue<T>::addQueueASyn(const T& item)
{
	if(!isQueueFull())
	{
		list[rear] =item;
		rear =(rear+1)%maxSize;
		return true;
	}
	else
	{
		//printf("The Array Queue was already Full!\n");
		return false;
	}
}

template<typename T>
bool ArrQue<T>::delQueueASyn(T& deletedItem)
{
	if(!isQueueEmpty())
	{
		deletedItem =list[front];
		front =(front+1)%maxSize;
		return true;
	}
	else
	{
	   //printf("The Array Queue was already Empty!\n");
	   return false;
	}
}

#endif

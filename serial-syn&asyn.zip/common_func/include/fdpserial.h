/*
 * fdpserial.h
 *
 *  Created on: Sep 20, 2016
 *      Author: su
 */

#ifndef FDPSERIAL_H_
#define FDPSERIAL_H_

#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <boost/thread.hpp>
#include "MemCache.h"

typedef unsigned char       uint8;
typedef signed char         sint8;
typedef unsigned short      uint16;
typedef signed short        sint16;
typedef unsigned int        uint32;
typedef signed int          sint32;
typedef unsigned long       ulng32;
typedef signed long         slng32;
typedef signed long long    sint64;
typedef unsigned long long  uint64;

#define ALL_SERIALS_NUM  5 /*需与串口数目保持同步，与以下type最大值相同*/
//设置select函数的timeout
#define TIMEOUT_SEC(buflen, baudrate)    ((buflen)*20/(baudrate) + 2)
#define TIMEOUT_USEC    0

typedef enum
{
    E_MOTOR_BOARD = 1,   //连接驱动板串口
    E_ULTRASONIC,        //超声波
    E_AIR_CHECK,         //激光粉尘
    E_RESERVER,          //预留
    E_SERIAL_PAD        //上位机平板
}SERIAL_TYPE;

/*串口通信协议号*/
typedef enum
{
	SERIAL_PROTO_FDP = 1/*fd fb fe 转义协议*/
} Serial_Protocol_Type;

typedef enum
{
    E_BAUERATE_2400,
    E_BAUERATE_4800,
    E_BAUERATE_9600,
    E_BAUERATE_115200
}SERIAL_BAUDRATE;

typedef enum
{
    E_DATA_BITS_7,
	E_DATA_BITS_8
}DATA_BITS;

typedef enum
{
    E_CHECK_ODD,//奇校验
    E_CHECK_EVEN,//偶数校验
    E_CHECK_NONE //无校验
}CHECK_TYPE;

typedef enum
{
    E_ONE_BIT,
    E_TWO_BIT
}STOP_BITS;

typedef struct
{
	SERIAL_BAUDRATE baudrate;
	DATA_BITS data_bits;
	CHECK_TYPE check_type;
	STOP_BITS stop_bits;
}Serial_Attr,PSerial_Attr;

typedef struct
{
    SERIAL_BAUDRATE rate;
    int fd;
}SERRIAL_HANDLE;

typedef struct
{
  Serial_Protocol_Type serial_protocol_num;/*协议号*/
  uint8 u08_opened_num;/*当前串口打开的次数*/
  uint8 u08_serial_index;/*当前串口序号*/
  uint8 u08_reserved1;
  uint8 u08_reserved2;
} Serial_Note;

typedef struct
{
	Serial_Note serial_note;/*一些记录*/
	uint32* pu32_curr_sio_hdl;
}Serial_Handle,*PSerial_Handle;

class SerialTool {

public:
	/*初始化平台串口*/
	static int platformSerialInit()
	{
		uint32 i = 0;
		if(0 == l_u08_init_flag)
		{
	        memset((char*)&g_platform_serial[0], 0, sizeof(Serial_Handle)*(ALL_SERIALS_NUM+1));
			for(i=0; i<=ALL_SERIALS_NUM; i++)
			{
				g_platform_serial[i].serial_note.u08_serial_index = i;
			}
			l_u08_init_flag = 1;
		}
	    return 0;
	}

	static bool isSerialTypeValid(SERIAL_TYPE serial_type)
	{
		switch(serial_type)
		{
		case E_ULTRASONIC:
		case E_AIR_CHECK:
		case E_RESERVER:
		case E_MOTOR_BOARD:
		case E_SERIAL_PAD:
			return true;
		default:
			return false;
		}
	}

	/*******************************************************************************
	* 函数名称: is_serial_baud_valid
	* 功能描述: 判断串口波特率是否合法
	* 参数:
	*      [输入参数]：
	*                serial_baud-波特率
	*      [输出参数]:
	*                无
	* 返回值:
	*        合法   --- true
	*        不合法 --- false
	* 其他说明:
	*
	*******************************************************************************/
	static bool isSerialBaudrateValid(SERIAL_BAUDRATE baud_rate)
	{
		switch(baud_rate)
		{
		case E_BAUERATE_2400:
		case E_BAUERATE_4800:
		case E_BAUERATE_9600:
		case E_BAUERATE_115200:
			return true;
		default:
			return false;
		}
	}

	/*******************************************************************************
	* 函数名称: is_serial_baud_valid
	* 功能描述: 判断串口数据位是否合法
	* 参数:
	*      [输入参数]：
	*                data_bits-数据位
	*      [输出参数]:
	*                无
	* 返回值:
	*        合法   --- true
	*        不合法 --- false
	* 其他说明:
	*
	*******************************************************************************/
	static bool isSerialDatabitsValid(DATA_BITS data_bits)
	{
		switch(data_bits)
		{
		case E_DATA_BITS_7:
		case E_DATA_BITS_8:
			return true;
		default:
			return false;
		}
	}

	/*******************************************************************************
	* 函数名称: is_serial_stopbits_valid
	* 功能描述: 判断串口停止位是否合法
	* 参数:
	*      [输入参数]：
	*                data_bits-数据位
	*      [输出参数]:
	*                无
	* 返回值:
	*        合法   --- true
	*        不合法 --- false
	* 其他说明:
	*
	*******************************************************************************/
	static bool isSerialStopbitsValid(STOP_BITS stop_bits)
	{
		switch(stop_bits)
		{
		case E_ONE_BIT:
		case E_TWO_BIT:
			return true;
		default:
			return false;
		}
	}

	/*******************************************************************************
	* 函数名称: is_serial_check_type_valid
	* 功能描述: 判断串口校验类型是否合法
	* 参数:
	*      [输入参数]：
	*                data_bits-数据位
	*      [输出参数]:
	*                无
	* 返回值:
	*        合法   --- true
	*        不合法 --- false
	* 其他说明:
	*
	*******************************************************************************/
	static bool isSerialCheckTypeValid(CHECK_TYPE check_type)
	{
		switch(check_type)
		{
		case E_CHECK_EVEN:
		case E_CHECK_ODD:
		case E_CHECK_NONE:
			return true;
		default:
			return false;
		}
	}

	static int uartOpen(int *handle,SERIAL_TYPE serial_type)
	{
	    const char *dev[]={"/dev/ttyO0","/dev/ttyO1","/dev/ttyO2","/dev/ttyO3","/dev/ttyO4","/dev/ttyO5"};
	    SERRIAL_HANDLE *serial = (SERRIAL_HANDLE *)malloc(sizeof(SERRIAL_HANDLE));
	    if (NULL == serial)
	        return -1;
	    serial->fd = open(dev[(int)serial_type], O_RDWR | O_NOCTTY | O_NDELAY);
	    if (-1 == serial->fd)
	    {
	        perror("Can't Open Serial Port");
	        return(-1);
	    }
	    if(fcntl(serial->fd, F_SETFL, 0) < 0)
	    {
	        printf("fcntl failed!\n");
	    }
	    if(isatty(STDIN_FILENO) == 0)
	    {
	//        evo_msg("standard input is not a terminal device\n");
	    }
    	    *handle = (int)serial;
	    return 0;
	}

	static int uartSet(int handle, SERIAL_BAUDRATE speed, DATA_BITS data_bits, CHECK_TYPE check_type, STOP_BITS stop)
	{
		if(handle == 0)
		{
		    perror("error:uart_set handle invalid");
			return -1;
		}
	    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
	    struct termios newtio,oldtio;
	    if(tcgetattr( serial->fd,&oldtio) != 0)
	    {
	        perror("SetupSerial 1");
	        return -1;
	    }
	    bzero(&newtio, sizeof(newtio));
	    newtio.c_cflag |= CLOCAL | CREAD;
	    newtio.c_cflag &= ~CSIZE;
	    switch(data_bits)
	    {
	    case E_DATA_BITS_7:
	        newtio.c_cflag |= CS7;
	        break;
	    case E_DATA_BITS_8:
	        newtio.c_cflag |= CS8;
	        break;
	    }
	    switch(check_type)
	    {
	    case E_CHECK_ODD:                     //奇校验
	        newtio.c_cflag |= PARENB;
	        newtio.c_cflag |= PARODD;
	        newtio.c_iflag |= (INPCK | ISTRIP);
	        break;
	    case E_CHECK_EVEN:                     //偶校验
	        newtio.c_iflag |= (INPCK | ISTRIP);
	        newtio.c_cflag |= PARENB;
	        newtio.c_cflag &= ~PARODD;
	        break;
	    case E_CHECK_NONE:                     //无校验
	        newtio.c_cflag &= ~PARENB;
	        break;
	    }
	    switch(speed)
	    {
	    case E_BAUERATE_2400:
	        cfsetispeed(&newtio, B2400);
	        cfsetospeed(&newtio, B2400);
	        break;
	    case E_BAUERATE_4800:
	        cfsetispeed(&newtio, B4800);
	        cfsetospeed(&newtio, B4800);
	        break;
	    case E_BAUERATE_9600:
	        cfsetispeed(&newtio, B9600);
	        cfsetospeed(&newtio, B9600);
	        break;
	    case E_BAUERATE_115200:
	        cfsetispeed(&newtio, B115200);
	        cfsetospeed(&newtio, B115200);
	        break;
	    default:
	        cfsetispeed(&newtio, B9600);
	        cfsetospeed(&newtio, B9600);
	        break;
	    }
	    if(stop == E_ONE_BIT)
	    {
	        newtio.c_cflag &= ~CSTOPB;
	    }
	    else if (stop == E_TWO_BIT)
	    {
	        newtio.c_cflag |= CSTOPB;
	    }
	    newtio.c_cc[VTIME] = 0;
	    newtio.c_cc[VMIN] = 0;
	    tcflush(serial->fd,TCIFLUSH);
	    if((tcsetattr(serial->fd,TCSANOW,&newtio))!=0)
	    {
	        perror("com set error");
	        return -1;
	    }
	    serial->rate = speed;
	    return 0;
	}

	static sint32 uartRead(int handle, uint8 *data, sint32 size)
	{
		if(handle == 0)
		{
		    perror("error:uart_read handle invalid");
			return -1;
		}

	    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
	    int len = 0;
	    len = read(serial->fd, data, size);
	    if (len < 0)
	    {
	        return -1;
	    }
	    else
	    {
	        return (len);
	    }
	}

	static sint32 uartWrite(int handle, uint8 *data, sint32 size)
	{
		if(handle == 0)
		{
		    perror("error:uart_write handle invalid");
			return -1;
		}

	    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
	    unsigned char *write_data = data;

	    int total_len = 0, retval = 0, len = 0;

	    fd_set fsWrite;

	    struct timeval tvTimeOut;

	    memset(&tvTimeOut, 0x00, sizeof(tvTimeOut));

	    //每次循环都要清空集合，否则不能检测描述符变化
	    FD_ZERO(&fsWrite);

	    //存放的是文件描述符即文件句柄
	    FD_SET(serial->fd, &fsWrite);
	    tvTimeOut.tv_sec  = TIMEOUT_SEC(size, rate_array[serial->rate]);
	    tvTimeOut.tv_usec = TIMEOUT_USEC;

	    for (total_len = 0; total_len < size;)
	    {
	        retval = select(serial->fd + 1, NULL, &fsWrite, NULL, &tvTimeOut);

	        if (retval < 0)
	        {
	            return -1;
	        }
	        else if (retval && FD_ISSET(serial->fd, &fsWrite))
	        {
	            //往串口写
	            len = write(serial->fd, &write_data[total_len], size - total_len);

	            if (len > 0)
	            {
	                total_len += len;
	            }
	            else if (len < 0)
	            {
	                if (total_len == 0)
	                {
	                    //刷新串口
	                    tcflush(serial->fd, TCOFLUSH);
	                    return -1;
	                }
	                return total_len;
	            }
	        }
	        else
	        {
	            if (total_len == 0)
	            {
	                tcflush(serial->fd, TCOFLUSH);
	                return -1;
	            }
	            break;
	        }
	    }
	    return total_len;
	}

	static int uartClose(int handle)
	{
		if(handle == 0)
		{
		    perror("error:uart_close handle invalid");
			return -1;
		}

	    SERRIAL_HANDLE *serial  = (SERRIAL_HANDLE *)handle;
	    if (handle <= 0)
	    {
	        return -1;
	    }
	    //关闭串口
	    close(serial->fd);
	    free(serial);
	    return 0;
	}

	friend class FdpSerial;

private:

	static Serial_Handle g_platform_serial[ALL_SERIALS_NUM+1];/*下标0可能没用*/
	static uint8 l_u08_init_flag;/*0-未初始化；1-已经初始化，*/
	static const int rate_array[];
};

class FdpSerial {
public:
	FdpSerial(bool bAsyn = true);
	virtual ~FdpSerial();
	/*******************************************************************************
	* 函数名称: fdpSerialOpen
	* 功能描述: 初始化串口
	* 参数:
	*      [输入参数]：
					 serial_type:指示当前串口类别
	*      [输出参数]:
	*                无
	* 返回值:
	*        返回错误号---失败
	*        0         ---成功
	* 其他说明:
	*
	*******************************************************************************/
	int fdpSerialOpen(SERIAL_TYPE serial_type);

	/*******************************************************************************
	* 函数名称: fdpSerialClose
	* 功能描述: 关闭串口
	* 参数:
	*      [输入参数]：
	*                u32_serial_hdl:串口句柄
	*      [输出参数]:
	*                无
	* 返回值:
	*        返回错误号---失败
	*        0         ---成功
	* 其他说明:
	*
	*******************************************************************************/
	int fdpSerialClose();

	/*******************************************************************************
	* 函数名称: fdpSerialSet
	* 功能描述: 设置串口
	* 参数:
	*      [输入参数]：
	*                u32_serial_hdl：串口句柄
					 p_serial_attr：串口属性
	*      [输出参数]:
	*                无
	* 返回值:
	*        返回错误号---失败
	*        0         ---成功
	* 其他说明:
	*
	*******************************************************************************/
	int fdpSerialSet(Serial_Attr* p_serial_attr);

	/*******************************************************************************
	* 函数名称: fdpFormatPacket
	* 功能描述: 封装串口格式
	* 参数:
	*      [输入参数]：
	*                srcbuf：存储串口数据的缓冲指针(无转义符的数据)
					 destbuf:用于存储转义之后的数据；
					 srclen：写入数据的长度
	*      [输出参数]:
	*                转移后的数据
	* 返回值:
	*        返回错误号        ---失败
	*        转义后的数据长度  ---成功
	* 其他说明:
	*
	*******************************************************************************/
	sint32 fdpFormatPacket(uint8* srcbuf, uint8* destbuf, uint32 srclen);

	/*******************************************************************************
	* 函数名称: fdpSerialRead
	* 功能描述: 读取串口整包数据
	* 参数:
	*      [输入参数]：
	*                u32_serial_hdl：串口句柄
					 pu8_read_buf：存储串口数据缓冲区；
					 u32_max_len：缓冲长度(读取最大长度)
	*      [输出参数]:
	*                串口整包数据
	* 返回值:
	*        返回错误号        ---失败
	*        读取到的数据长度  ---成功
	* 其他说明:
	*
	*******************************************************************************/
	sint32 fdpSerialRead(uint8* pu8_read_buf,uint32 u32_max_len);

	/*******************************************************************************
	* 函数名称: fdpSerialWrite
	* 功能描述: 写串口数据
	* 参数:
	*      [输入参数]：
					u32_serial_hdl:串口句柄；
					pu8_write_buf:存储串口数据的缓冲指针(无转义符的数据)；
					u32_buf_len:写入数据的长度；
	*      [输出参数]:
	*                无
	* 返回值:
	*        返回错误号        ---失败
	*        COMMON_OK  	   ---成功
	* 其他说明:
	*
	*******************************************************************************/
	sint32 fdpSerialWrite(uint8* pu8_write_buf,uint32 u32_data_len);


private:

	int fdpCheckSum(uint8* ucCheckData,uint32 uiCheckNum);
	void thread_recv();

	PSerial_Handle m_pSerHandle;
	boost::thread* m_pThreadRecv;
	MemCache* m_pMem;
};

#endif /* FDPSERIAL_H_ */

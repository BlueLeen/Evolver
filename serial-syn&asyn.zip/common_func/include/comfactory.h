#ifndef COMMONFUNC_COMMUFACTORY_H_
#define COMMONFUNC_COMMUFACTORY_H_

#include <iostream>
#include "commu.h"

class CommuFactory
{
public:
	virtual ~CommuFactory(){};
	virtual Commu* createCommu() = 0;
};

#endif

/*
 * MemCache.h
 *
 *  Created on: Sep 21, 2016
 *      Author: su
 */

#ifndef MEMCACHE_H_
#define MEMCACHE_H_

#include "ArrQue.h"

#define START                   	0xFD        /* indicates start of packet */
#define END                       	0xF8        /* indicates end of packet */
#define ESC                        	0xFE        /* indicates byte stuffing */
#define ESC_START           		0x7D        /* ESC ESC_START means START data byte */
#define ESC_END              		0x78        /* ESC ESC_END means END data byte */
#define ESC_ESC               		0x7E        /* ESC ESC_ESC means ESC data byte */

class MemCache {
public:
	MemCache(bool bAsyn = true);
	virtual ~MemCache();
	void recvAdd(unsigned char* buf, unsigned int len);
	int recvDel(unsigned char* buf);
private:
	void recvAddSyn(unsigned char* buf, unsigned int len);
	int recvDelSyn(unsigned char* buf);
	void recvAddAsyn(unsigned char* buf, unsigned int len);
	int recvDelAsyn(unsigned char* buf);
	bool bRecvAsyn;
	ArrQue<unsigned char> *arrbuf;
};

#endif /* MEMCACHE_H_ */

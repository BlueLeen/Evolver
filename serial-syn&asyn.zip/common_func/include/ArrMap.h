#ifndef ARRMAP_H_
#define ARRMAP_H_

#include <sys/time.h>
#include <iostream>
#include <map>

typedef struct _SeqCode
{
	timeval tm;
	unsigned short key;
	int seq_num;
	int timeout_cnt;

	_SeqCode(timeval tv, unsigned short code, int orderNum):tm(tv), key(code), seq_num(orderNum), timeout_cnt(0)
	{
	}

	void update(timeval tv){tm = tv;};

	_SeqCode& operator= (const _SeqCode& sc)
	 {
		tm = sc.tm;
		key = sc.key;
		seq_num = sc.seq_num;
		return *this;
	 }

    bool operator < (const _SeqCode& sc) const
    {
    	if(tm.tv_sec!=sc.tm.tv_sec || ((tm.tv_sec==sc.tm.tv_sec)&&tm.tv_usec!=sc.tm.tv_usec))
    		return tm.tv_sec <= sc.tm.tv_sec ? (tm.tv_sec<sc.tm.tv_sec?true:(tm.tv_usec<sc.tm.tv_usec ? true:false)):false;
    	else if(key != sc.key)
    		return key < sc.key ? true:false;
    	else
    		return seq_num < sc.seq_num ? true:false;
    	/*
        if (tm.tv_sec < sc.tm.tv_sec)
        {
            return true;
        }
        else if (sc.tm.tv_sec < tm.tv_sec)
        {
            return false;
        }
        else if(tm.tv_sec == sc.tm.tv_sec && tm.tv_usec < sc.tm.tv_usec)
        {
        	return true;
        }
        else if(tm.tv_sec == sc.tm.tv_sec && sc.tm.tv_usec < tm.tv_usec)
        {
        	return false;
        }
        else if(key < sc.key)
        {
            return true;
        }
        else if(sc.key < key)
        {
            return false;
        }
        else
        {
            return seq_num < sc.seq_num;
        }
        */
    }

//    bool operator== (const _SeqCode& sc) const
//    {
//    	return key==sc.key && seq_num==sc.seq_num;
//    }

}SeqCode;

//class SeqCodeComparator
//{
//public:
//    bool operator()(const SeqCode& sc1, const SeqCode& sc2) const
//    {
//        if (sc1.tm.tv_sec < sc2.tm.tv_sec)
//        {
//            return true;
//        }
//        else if (sc2.tm.tv_sec < sc1.tm.tv_sec)
//        {
//            return false;
//        }
//        else if(sc1.key < sc2.key)
//        {
//            return true;
//        }
//        else if(sc2.key < sc1.key)
//        {
//            return false;
//        }
//        else
//        {
//            return sc1.seq_num < sc2.seq_num;
//        }
//    }
//};

template <typename T>
class ArrMap
{
	friend std::ostream& operator<<(std::ostream& out, ArrMap<T>& am)
	{
		am.output(out);
		return out;
	}
public:
	ArrMap();
	~ArrMap();
	void addMap(unsigned short code, int seqNum, const T* item, int item_count);
	bool delMap(unsigned short code, int seqNum);

	typedef std::map<SeqCode, T*> SeqCodeMap;
	typedef typename SeqCodeMap::iterator ScMapIterator;
private:
	void output(std::ostream& out);
	void erase(ScMapIterator iter);
	//typedef std::map<timeval, int> MapSeq;
	SeqCodeMap m_mData;
};

//template <typename S>
//std::ostream& operator<<(std::ostream& out, ArrMap<S>& am)
//{
//
//	//ScMapIterator iter = am.m_mData.begin();
//}

template <typename T>
ArrMap<T>::ArrMap()
{
	if(!m_mData.empty())
		m_mData.clear();
}

template <typename T>
ArrMap<T>::~ArrMap()
{
    ScMapIterator iter = m_mData.begin();
    while(iter != m_mData.end())
    {
    	T* data = iter->second;
    	delete[] data;
    	++iter;
    }
	m_mData.clear();
}

template <typename T>
void ArrMap<T>::addMap(unsigned short code, int seqNum, const T* item, int item_count)
{
    struct timeval tm;
    gettimeofday(&tm, NULL);
    SeqCode sc(tm, code, seqNum);
    T* data = new T[item_count];
    memcpy(data, item, sizeof(T)*item_count);
    if(m_mData.size() >= 10)
    {
    	std::cout<<"The cached instructions is full of buffer area!"<<std::endl;
    	//m_mData.erase(m_mData.begin());
    	erase(m_mData.begin());
    }
    m_mData.insert(std::pair<SeqCode, T*>(sc, data));
}

template <typename T>
bool ArrMap<T>::delMap(unsigned short code, int seqNum)
{
    struct timeval tm;
    gettimeofday(&tm, NULL);
    SeqCode sc(tm, code, seqNum);
    ScMapIterator iter = m_mData.begin();
    ScMapIterator iterFind;
    while(iter != m_mData.end())
    {
    	if(((SeqCode)iter->first).key == code && ((SeqCode)iter->first).seq_num == seqNum)
		{
    		iterFind = iter;
    		break;
		}
    	++iter;
    }
    if(iter == m_mData.end())
    	return false;
    //m_mData.erase(iterFind);
    erase(iterFind);
    return true;
}

template <typename T>
void ArrMap<T>::output(std::ostream& out)
{
    ScMapIterator iter = m_mData.begin();
    while(iter != m_mData.end())
    {
    	out<<"time:"<<(((SeqCode)iter->first).tm.tv_sec)<<"."<<(((SeqCode)iter->first).tm.tv_usec)
    			<<",key:"<<((SeqCode)iter->first).key
				<<",sequence"<<((SeqCode)iter->first).seq_num
    			<<",timeout count:"<<((SeqCode)iter->first).timeout_cnt<<std::endl;
    	++iter;
    }
}

template <typename T>
void ArrMap<T>::erase(ScMapIterator iter)
{
	T* data = iter->second;
	delete[] data;
	m_mData.erase(iter);
}

#endif

#ifndef COMMONFUNC_COMSERIAL_H_
#define COMMONFUNC_COMSERIAL_H_

#include "commu.h"
#include "fdpserial.h"

class CommuSeiral : public Commu
{
public:
	CommuSeiral(uint8 type, bool asyn = true);
	~CommuSeiral();
	bool open();
	void close();
	int sendData(uint8* data, uint32 len);
	bool recvData(uint8* data, sint32& len);
private:
	char* getSerialType(char* strType, uint32 len);
private:
	//uint32 m_uFd;
	FdpSerial* m_pFdpSer;
	uint8 m_uType;
};


#endif

/*
 * SerialFactory.h
 *
 *  Created on: Sep 27, 2016
 *      Author: su
 */

#ifndef SERIALFACTORY_H_
#define SERIALFACTORY_H_
#include "comfactory.h"

class SerialFactory : public CommuFactory {
public:
	SerialFactory(int type);
	virtual ~SerialFactory();
	Commu* createCommu();
private:
	int m_nType;
};

#endif /* SERIALFACTORY_H_ */


#ifndef EVO_INTERFACE_H
#define EVO_INTERFACE_H

#ifdef __cplusplus
extern "C"
{
#endif         // __cplusplus

#include <stdio.h>
#include "common_msgs/common.h"

#define         LOG_PATH                        "/app/log"
#define         LOG_FILE_SIZE_MAX               (1024 * 1024)

#define         EVO_CONFIG_PATH                 "/app/evo_ros_config.xml"
#define         EVO_VERSION_OLD_PATH            "/app/version.xml"
#define         EVO_VERSION_PATH                "/app/config/version.xml"
#define         DRIVER_CONFIG_PATH              "/app/config/driver_config.xml"
#define         LOCAL_CONFIG_PATH               "/app/config/local_config.xml"
#define         CHARGE_CONFIG_PATH              "/app/config/charge_config.xml"


#define         PI                              3.1415926

#define         TRAY_LENGTH_MAX                 162                   //托盘最大长度(mm)
#define         WING_LENGTH_MAX                 140                   //翅膀最大长度(mm)

#define         SERIAL_DATA_LEN                  1024                 //串口数据最大大小
#define         SERIAL_DATA_CONST_SIZE           13                   //帧数据固定大小（1帧头+2帧长度+4指令码+4预留位+1校验+1帧尾）
#define         SERIAL_DATA_HEAD                 0xFD                 //帧头
#define         SERIAL_DATA_TAIL                 0XF8                 //帧尾

#define         INFRARED_COUNT                           7               //红外探头数目
#define         ULTRASONIC_COUNT                         13              //超声波探头数目

#define         ULTRASONIC_DATA_VALID_NO_BARRIER    0x1fff          //超声波数据探测为无障碍
#define         ULTRASONIC_DATA_VALID_BLIND         400             //超声波数据探测盲区数值
#define         ULTRASONIC_DATA_TIMEOUT             0xffff          //超声波数据超时
#define         ULTRASONIC_DATA_VALID_MAX           6000            //超声波数据最大有效范围
#define         INFRARED_VOLTAGE_MAX                1782            //红外电压最大值
#define         INFRARED_INIT_VOLTAGE               300             //数据初始化默认值

#define         DISTANCE_TO_CODES                   0.141844        //默认距离转码数
#define         ANGLE_TO_CODES                      27.665329       //默认角度转码数

#define ALL_SERIALS_NUM  5 /*需与串口数目保持同步，与以下type最大值相同*/
typedef enum
{
    E_MOTOR_BOARD = 1,   //连接驱动板串口
    E_ULTRASONIC,        //超声波
    E_AIR_CHECK,         //激光粉尘
    E_RESERVER,          //预留
    E_SERIAL_PAD        //上位机平板
}SERIAL_TYPE;


typedef enum
{
    E_BAUERATE_2400,
    E_BAUERATE_4800,
    E_BAUERATE_9600,
    E_BAUERATE_115200
}SERIAL_BAUDRATE;


typedef enum
{
    E_DATA_BITS_7,
	E_DATA_BITS_8	
}DATA_BITS;


typedef enum
{
    E_CHECK_ODD,//奇校验
    E_CHECK_EVEN,//偶数校验
    E_CHECK_NONE //无校验
}CHECK_TYPE;

typedef enum
{
    E_ONE_BIT,
    E_TWO_BIT
}STOP_BITS;


//双轮补偿
typedef struct
{
    float left_wheel_forward;           //左轮向前补偿
    float left_wheel_backward;          //左轮向后补偿
    float right_wheel_forward;          //右轮向前补偿
    float right_wheel_backward;         //右轮向后补偿

}WHEELS_MODIFY, *PWHEELS_MODIFY;

//码数转距离
typedef struct
{
    float cofficient_modify;            //转换系数
    float driver_servo_interval;        //驱动伺服间隔时间（ms）

}CODES_TO_DISTANCE, *PCODES_TO_DISTANCE_MODIFY;


typedef struct
{
    char			    dest[64];
    WHEELS_MODIFY       control_modify;             //跑直补偿
    WHEELS_MODIFY       dead_reckon_modify;         //航位补偿
    CODES_TO_DISTANCE   codes_to_distance;          //码数转距离
    float               wheels_spaces_modify;       //轮间距补偿

}DRIVER_CONFIG, *PDRIVER_CONFIG;

typedef struct
{
    char	dest[64];
    uint32  fan_time;                               //风机工作时间
    char    serial_num[64];                         //串行号
    uint16  infrared_init[7];                       //红外数据初始值(7个)
    uint32  charge_pile_id;                        //充电桩ID
    uint32  charge_type;                           //充电桩绑定状态
    char   charge_pile_ver[128];
    uint8 charge_channel;

}WORK_CONFIG, *PWORK_CONFIG;

typedef struct
{
    char	dest[64];
    uint32  fan_time;                               //风机工作时间
    char    serial_num[64];                         //串行号
    uint16  infrared_init[7];                       //红外数据初始值(7个)

}LOCAL_CONFIG, *PLOCAL_CONFIG;

typedef struct
{
    uint32  charge_pile_id;                        //充电桩ID
    uint32  charge_type;                           //充电桩绑定状态
    char    charge_pile_ver[128];                  //充电桩版本号
    uint32  charge_channel;                        //充电桩频段

}CHARGE_CONFIG, *PCHARGE_CONFIG;

typedef struct
{
    char    sys_version[128];                       //下位机版本号
    char    driver_version[128];                    //驱动版本号
    char    ultra_version[128];                     //超声波版本号
    char   charge_version[128];                                //充电桩类型 0-无充电桩  1-带id充电桩 2-不带id充电桩

}VERSION_CONFIG, *PVERSION_CONFIG;

//配置文件参数
typedef struct
{
    DRIVER_CONFIG       driver_config;              //驱动板配置参数
    WORK_CONFIG         work_config;                //运行配置参数
}CONFIG_DATA, *PCONFIG_DATA;


//公共函数

int serial_power_status(SERIAL_TYPE serial_type, int status);

int uart_open(int *handle,SERIAL_TYPE serial_type);
int uart_set(int handle, SERIAL_BAUDRATE speed, DATA_BITS data_bits, CHECK_TYPE check_type, STOP_BITS stop);
sint32 uart_tcflush(int handle);
sint32 uart_read(int handle, uint8 *data, sint32 size); 
sint32 uart_write(int handle, uint8 *data, sint32 size);
sint32 uart_close(int handle);

int unlock_motor();

int litter_big_convert(uint8* dest_data, const uint8* src_data, int length);
uint8* litter_big_convert_self(uint8* src_data, int length);

FILE* evo_log_open(const char* file_name, const char* type);
int evo_log_write(FILE* fp, char* str, ...);
int evo_log_close(FILE* fp);

//动态申请二维数组
char** malloc_Array2D(int row, int col);

//释放二维数组
void free_Aarray2D(void **arr);

#ifdef __cplusplus
}
#endif                /* __cplusplus */


#endif // EVO_INTERFACE_H

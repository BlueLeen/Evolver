#ifndef COMMONFUNC_COMMU_H_
#define COMMONFUNC_COMMU_H_

typedef unsigned char       uint8;
typedef signed char         sint8;
typedef unsigned short      uint16;
typedef signed short        sint16;
typedef unsigned int        uint32;
typedef signed int          sint32;
typedef unsigned long       ulng32;
typedef signed long         slng32;
typedef signed long long    sint64;
typedef unsigned long long  uint64;

class Commu
{
public:
	virtual ~Commu(){};
	virtual bool open() = 0;
	virtual void close() = 0;
	virtual int sendData(uint8* data, uint32 len) = 0;
	virtual bool recvData(uint8* data, sint32& len) = 0;
};

#endif
